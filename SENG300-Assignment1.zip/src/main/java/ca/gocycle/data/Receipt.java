package ca.gocycle.data;

import java.util.*;
import java.time.*;
import java.math.*;
import java.nio.file.Path;
import java.util.concurrent.locks.ReentrantLock;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import ca.gocycle.application.*;
import ca.gocycle.config.*;
import ca.gocycle.domain.*;
import ca.gocycle.domain.fault.*;
import ca.gocycle.domain.rider.*;
import ca.gocycle.domain.station.*;
import ca.gocycle.domain.trip.*;
import ca.gocycle.domain.vehicle.*;
import ca.gocycle.fault.*;
import ca.gocycle.integration.*;
import ca.gocycle.presentation.*;
import ca.gocycle.pricing.*;
import ca.gocycle.simulation.*;


public record Receipt(UUID id, UUID tripId, Instant paidAt, String currency, FareBreakdown fare, DepositStatus depositStatus) {
    public Receipt {
        if (id == null || tripId == null || paidAt == null || fare == null || depositStatus == null
                || currency == null || currency.isBlank()) {
            throw new IllegalArgumentException("Receipt fields are required");
        }
    }
}
