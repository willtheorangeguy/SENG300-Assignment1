package ca.gocycle.data;

import java.util.*;
import java.time.*;
import java.math.*;
import java.nio.file.Path;
import java.util.concurrent.locks.ReentrantLock;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import ca.gocycle.application.*;
import ca.gocycle.config.*;
import ca.gocycle.domain.*;
import ca.gocycle.domain.fault.*;
import ca.gocycle.domain.rider.*;
import ca.gocycle.domain.station.*;
import ca.gocycle.domain.trip.*;
import ca.gocycle.domain.vehicle.*;
import ca.gocycle.fault.*;
import ca.gocycle.integration.*;
import ca.gocycle.presentation.*;
import ca.gocycle.pricing.*;
import ca.gocycle.simulation.*;


public record PaymentResult(boolean success, String reference, String failureCode, String failureMessage) {
    public PaymentResult {
        if (success) {
            if (reference == null || reference.isBlank() || failureCode != null || failureMessage != null) {
                throw new IllegalArgumentException("Successful payments require a reference and no failure details");
            }
        } else if (reference != null || failureCode == null || failureCode.isBlank()
                || failureMessage == null || failureMessage.isBlank()) {
            throw new IllegalArgumentException("Failed payments require failure details and no reference");
        }
    }
}
